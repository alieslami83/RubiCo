class copyright:
	__Version__ = "0.0.1"
	CopyRight = print(f"\n\npyRubiCo library version {__Version__} \n\n" + "Arsein Copyright (C) 2022 Ali Eslami Team pyRubiCo\n\n\n\n")
	print("........")
	print(" ")
