class DeviceTelephone:

	defaultDevice = {
	"app_version":"MA_3.1.0",
	"device_hash":"CEF34215E3E610825DC1C4BF9864D47A",
	"device_model":"rubika-library",
	"is_multi_account": False,
	"lang_code":"fa",
	"system_version":"SDK 22",
	"token":"pypi-AgEIcHlwaS5vcmcCJGM2NmIxNzRjLWEwMzItNDk0Zi1iNzVkLWMzNjRlYTM4ODM0NgACKlszLCJlMmFkOGQxZC0zNzQxLTQxNmItYTQzOS0wNWM1Mzc4ODIwZTgiXQAABiDe_T9C0cHS0hHgH4L74ff_7S3s399MHXhJP3Vj5Dmzkw",
	"token_type":"Firebase"
}