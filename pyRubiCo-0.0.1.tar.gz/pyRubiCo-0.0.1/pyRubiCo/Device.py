class DeviceTelephone:

	defaultDevice = {
	"app_version":"MA_3.1.0",
	"device_hash":"CEF34215E3E610825DC1C4BF9864D47A",
	"device_model":"rubika-library",
	"is_multi_account": False,
	"lang_code":"fa",
	"system_version":"SDK 22",
	"token":"cgpzI3mbTPKddhgKQV9lwS:APA91bE3ZrCdFosZAm5qUaG29xJhCjzw37wE4CdzAwZTawnHZM_hwZYbPPmBedllAHlm60v5N2ms-0OIqJuFd5dWRAqac2Ov-gBzyjMx5FEBJ_7nbBv5z6hl4_XiJ3wRMcVtxCVM9TA-",
	"token_type":"Firebase"
}