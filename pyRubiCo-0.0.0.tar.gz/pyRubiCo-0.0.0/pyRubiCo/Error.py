class AuthError(Exception):
	pass

class TypeMethodError(Exception):
	pass

class TypeAnti(Exception):
	pass

class ErrorServer(Exception):
	pass