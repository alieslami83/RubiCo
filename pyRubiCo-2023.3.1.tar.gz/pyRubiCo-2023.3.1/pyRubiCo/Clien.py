class clien:
    web = {
        "app_name": "Main",
        "app_version": "4.4.3",
        "platform": "Web",
        "package": "web.rubika.ir",
        "lang_code": "fa"
    }

    android = {
        "app_name": "Main",
        "app_version": "3.4.2",
        "platform": "Android",
        "package": "app.rbmain.a",
        "lang_code": "fa"
    }
		