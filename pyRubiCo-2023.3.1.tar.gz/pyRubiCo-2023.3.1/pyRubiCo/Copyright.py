class copyright:
	__Version__ = "2023.2.1"
	CopyRight = print(f"\n\npyRubiCo library version {__Version__} \n\n" + "pyRubiCo Copyright (C) 2023 Ali Eslami Team pyRubiCo\n\n\n\n")
	print("........")
	print(" ")
