from .methods import methods as Bot
from .tools import tools as Tools

__version__ = '2023.1.1'
__author__ = 'AliEslami'
__github__ = 'https://github.com/alitektanus/RubiCo'